from setuptools import setup
setup(
    name="recursos_humanos",
    version="0.2",
    description="Paquete de ejemplo de empleados y nómina",
    author="Codo a Codo",
    author_email="io.codoacodo@bue.edu.ar",
    url="https://www.buenosaires.gob.ar/educacion/codo-codo",
    packages=['recursos_humanos', 'recursos_humanos.personal'],
    scripts=[]
)
